from microbit import *

val = Image("00900:""00900:""90909:""09990:""00900")

display.show(val)
